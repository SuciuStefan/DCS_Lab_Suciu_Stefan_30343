package labul3_1;

import java.util.ArrayList;

import Components.Activation;
import Components.Condition;
import Components.GuardMapping;
import Components.PetriNet;
import Components.PetriTransition;
import DataObjects.DataFuzzy;
import DataOnly.Fuzzy;
import DataOnly.PlaceNameWithWeight;
import Enumerations.LogicConnector;
import Enumerations.TransitionCondition;
import Enumerations.TransitionOperation;

// ... importuri standard ...

public class HTC_PI {
    public static void main(String[] args) throws Exception {
        PetriNet pn = new PetriNet();
        pn.PetriNetName = "HTC PI";
        pn.NetworkPort = 1083;

        // ... Inițializare FLRS și P0 - P8 ...
        // Adăugăm locații suplimentare pentru memoria PI
        DataFuzzy p9 = new DataFuzzy(); p9.SetName("P9"); pn.PlaceList.add(p9);
        DataFuzzy p10 = new DataFuzzy(); p10.SetName("P10"); p10.SetValue(new Fuzzy(0.0F)); pn.PlaceList.add(p10);

        // Modificăm T4 pentru a însuma comanda proporțională cu acumularea anterioară
        PetriTransition t4 = new PetriTransition(pn);
        t4.TransitionName = "T4";
        t4.InputPlaceName.add("P4");
        t4.InputPlaceName.add("P10"); // Memoria integralei
        Condition T4Ct1 = new Condition(t4, "P4", TransitionCondition.NotNull);
        Condition T4Ct2 = new Condition(t4, "P10", TransitionCondition.NotNull);
        T4Ct1.SetNextCondition(LogicConnector.AND, T4Ct2);
        GuardMapping grdT4 = new GuardMapping();
        grdT4.condition = T4Ct1;
        
        ArrayList<PlaceNameWithWeight> input4 = new ArrayList<>();
        input4.add(new PlaceNameWithWeight("P4", 1.2F)); // Ponderea proporțională (Kp)
        input4.add(new PlaceNameWithWeight("P10", 1.0F)); // Ponderea integrală (Ki)
        
        ArrayList<String> Output4 = new ArrayList<>();
        Output4.add("P7"); // Spre output
        Output4.add("P9"); // Spre bucla de delay
        grdT4.Activations.add(new Activation(t4, doubleChannelAdder, input4, TransitionOperation.FLRS, Output4));
        t4.GuardMappingList.add(grdT4);
        t4.Delay = 0;
        pn.Transitions.add(t4);

        // T9 - Delay pentru integrala PI
        PetriTransition t9 = new PetriTransition(pn);
        t9.TransitionName = "T9";
        t9.InputPlaceName.add("P9");
        Condition T9Ct1 = new Condition(t9, "P9", TransitionCondition.NotNull);
        GuardMapping grdT9 = new GuardMapping();
        grdT9.condition = T9Ct1;
        grdT9.Activations.add(new Activation(t9, "P9", TransitionOperation.Move, "P10"));
        t9.GuardMappingList.add(grdT9);
        t9.Delay = 1; // 1 t.u. delay obligatoriu pentru k-1
        pn.Transitions.add(t9);
        
        // ... (Restul tranzițiilor T2, T5) ...
    }
}